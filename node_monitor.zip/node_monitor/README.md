# 节点监控服务

这是一个用于监控V2Board节点状态的独立服务。当发现节点掉线时，会通过Telegram通知管理员。

## 功能特点

- 每5分钟检查一次节点状态
- 只通知新掉线的节点，避免重复通知
- 自动记录日志到 `node_monitor.log`
- 支持后台运行
- 提供启动和停止脚本

## 使用方法

1. 确保已安装所需依赖：
```bash
pip install requests python-telegram-bot pytz
```

2. 确保 `Config.py` 文件中的配置正确：
   - `TELEGRAM.token`: Telegram机器人token
   - `TELEGRAM.admin_telegram_id`: 管理员Telegram ID
   - `WEBSITE.url`: 网站地址
   - `WEBSITE.email`: 管理员邮箱
   - `WEBSITE.password`: 管理员密码
   - `WEBSITE.suffix`: 网站后缀

3. 启动服务：
```bash
chmod +x start.sh
./start.sh
```

4. 停止服务：
```bash
chmod +x stop.sh
./stop.sh
```

## 日志查看

- 实时日志：`tail -f monitor.out`
- 历史日志：`cat node_monitor.log`

## 注意事项

1. 确保服务器时间正确
2. 确保网络连接稳定
3. 确保有足够的磁盘空间存储日志
4. 建议使用screen或tmux运行，以便在SSH断开后继续运行 