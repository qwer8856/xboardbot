#!/bin/bash

# 进入脚本所在目录
cd "$(dirname "$0")"

# 启动监控程序
nohup /root/v2boardbot/python-3.9.7/bin/python3.9 monitor.py > monitor.out 2>&1 &

# 保存进程ID
echo $! > monitor.pid

echo "节点监控服务已启动，进程ID: $(cat monitor.pid)" 