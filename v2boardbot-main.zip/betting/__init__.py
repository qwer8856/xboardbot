from betting.betting_slots import *
from betting.betting_open import *
from betting.betting_game import *