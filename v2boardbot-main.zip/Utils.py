import requests
import datetime
from Config import config
import pytz

START_ROUTES, END_ROUTES = 0, 1

WAITING_INPUT = 2


def _admin_auth():  # 返回网站管理员auth_data
    URL = config.WEBSITE.url
    api = URL + '/api/v1/passport/auth/login'
    data = {
        'email': config.WEBSITE.email,
        'password': config.WEBSITE.password,
    }
    res = requests.post(api, data=data)
    return res.json()['data']['auth_data']


def getNodes():
    try:
        URL = config.WEBSITE.url
        
        # 直接使用admin作为路径，不再依赖SUFFIX配置
        api = f'{URL}/api/v1/admin/server/manage/getNodes'
        headers = {
            'Authorization': _admin_auth()
        }
        
        # 添加调试信息
        print(f"请求节点API: {api}")
        print(f"请求Headers: {headers}")
        
        res = requests.get(api, headers=headers)
        print(f"API响应状态码: {res.status_code}")
        print(f"API响应内容: {res.text[:200]}...")  # 只打印前200个字符
        
        if res.status_code == 404:
            return '''❌ 获取节点信息失败
————————————
原因：API地址不存在
请确认以下配置：
1. 面板地址是否正确
2. 面板版本是否为v2board
3. 管理员账号是否正确'''
            
        if res.status_code != 200:
            return f'''❌ 获取节点信息失败
————————————
HTTP状态码：{res.status_code}
错误信息：{res.text}'''
            
        data = res.json()
        if not data.get('data'):
            return '''❌ 获取节点信息失败
————————————
原因：未获取到节点数据
请检查管理员账号权限'''
            
        text = '📡 节点状态\n————————————\n'
        online_nodes = 0
        total_nodes = 0
        total_users = 0
        
        for item in data['data']:
            if item.get('show', 0) == 0:
                continue
                
            total_nodes += 1
            node_name = item.get('name', '未命名节点')
            status = '🟢 在线' if item.get('available_status', False) else '🔴 离线'
            online = item.get('online', 0) or 0
            total_users += online
            
            if item.get('available_status', False):
                online_nodes += 1
            
            # 获取节点类型
            node_type = ''
            if 'type' in item:
                if item['type'] == 'vmess':
                    node_type = '[VMess]'
                elif item['type'] == 'trojan':
                    node_type = '[Trojan]'
                elif item['type'] == 'shadowsocks':
                    node_type = '[SS]'
                elif item['type'] == 'vless':
                    node_type = '[VLESS]'
            
            # 获取节点速率
            rate = item.get('rate', '1.0')
            rate_text = f"倍率:{rate}x" if rate != '1.0' else ''
            
            line = f'''节点: {node_type} {node_name}
状态: {status}
在线: {online}人
{rate_text}
————————————'''
            text += line + '\n'
            
        # 添加统计信息
        summary = f'''📊 节点统计
————————————
总节点数: {total_nodes}
在线节点: {online_nodes}
离线节点: {total_nodes - online_nodes}
总在线人数: {total_users}人'''
        
        if total_nodes == 0:
            return '当前无可用节点'
            
        return text + summary
        
    except requests.exceptions.RequestException as e:
        return f'''❌ 连接服务器失败
————————————
错误信息：{str(e)}
请检查面板地址是否正确'''
    except Exception as e:
        return f'''❌ 获取节点状态出错
————————————
错误信息：{str(e)}'''


def get_next_first():
    now = datetime.datetime.now(pytz.timezone('Asia/Shanghai'))
    for m in range(1, 6):
        open_minute = now + datetime.timedelta(minutes=m)
        if open_minute.minute % 5 == 0:
            open_date = open_minute.replace(second=0, microsecond=0)
            return open_date